export default {
  white: "#ffffff",
  black: "#000000",
  green: "#00AC76",
  red: "#C04345",
  blue: "#0043F9",
  darkBackground: "#333333",
  lightBackground: "#ffffff",
  lightText: "#ffffff",
  darkText: "#000000",
  pink: "",
  bgGreen: "#D0E7D2",
};
